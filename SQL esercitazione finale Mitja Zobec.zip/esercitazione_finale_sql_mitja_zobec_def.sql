create database toysgroup;

use toysgroup

/* creazione tabelle
paese:
paese: ho usato l'auto_increment, per garantire la consistenza del dato (nel corso degli anni recenti, sono nati molti paesi)
per garantire l’integrità referenziale e la minimizzazione della ridondanza dei dati, ho creato'apposita tabella 'regioni'
giocattoli: nella stella logica, ho creato un'apposita tabella 'categoria giocattoli'
clienti: considerato che l'esercizio non lo richiede, nella tabella transazioni non ho inserito informazioni inerenti i clienti. 
la mia suppposizione e che si venda ai clienti finali (non a terziSTI) e quindi l'informazione perde di efficacia */

create table regioni (
id_regione integer primary key,
nome_regione varchar (100))

insert into regioni (id_regione, nome_regione) values
(1,'Europa Centrale'),
(2,'Europa Meridionale'),
(3,'Europa Occidentale'),
(4,'Europa Orientale'),
(5,'Europa Settentrionale');

-- check dati regioni

select * from regioni

create table paesi (
id_paese integer primary key auto_increment,
codice_paese char (2),
nome_paese varchar (100),
id_regione integer,
foreign key (id_regione) references regioni(id_regione));

insert into paesi (codice_paese, nome_paese, id_regione) values
('AD','Andorra',3),
('AL','Albania',2),
('AT','Austria',1),
('BA','Bosnia-Erzegovina',2),
('BE','Belgio',3),
('BG','Bulgaria',4),
('BY','Bielorussia',4),
('CH','Svizzera',3),
('CY','Cipro',2),
('CZ','Repubblica Ceca',1),
('DE','Germania',3),
('DK','Danimarca',5),
('EE','Estonia',5),
('ES','Spagna',2),
('FI','Finlandia',5),
('FR','Francia',3),
('GB','Regno Unito',3),
('GR','Grecia',2),
('HR','Croazia',2),
('HU','Ungheria',1),
('IE','Irlanda',3),
('IS','Islanda',5),
('IT','Italia',2),
('LI','Liechtenstein',3),
('LT','Lituania',4),
('LU','Lussemburgo',3),
('LV','Lettonia',5),
('MC','Monaco',3),
('MD','Moldavia',4),
('ME','Montenegro',2),
('MK','Macedonia del Nord',2),
('MT','Malta',2),
('NL','Paesi Bassi',3),
('NO','Norvegia',5),
('PL','Polonia',4),
('PT','Portogallo',2),
('RO','Romania',4),
('RS','Serbia',2),
('RU','Russia',4),
('SE','Svezia',5),
('SI','Slovenia',2),
('SK','Slovacchia',1),
('SM','San Marino',2),
('TR','Turchia',2),
('UA','Ucraina',4),
('VA','Città del Vaticano',2),
('XK','Kosovo',2);

select * from paesi

create table categoria_giocattoli (
id_categoria_giocattolo integer primary key auto_increment,
descrizione_categoria_giocattolo varchar (100))

insert into categoria_giocattoli (descrizione_categoria_giocattolo) values
('Articoli per la creatività'),
('Bambole'),
('Costruzioni'),
('Giocattoli aperto'),
('Giocattoli educativi'),
('Giocattoli motorizzati'),
('Giocattoli tecnologici'),
('Giochi aperto'),
('Giochi da tavolo'),
('Giochi di prestigio'),
('Giochi di ruolo'),
('Giochi educativi'),
('Macchine radiocomandate'),
('Modellismo'),
('Peluche'),
('Puzzle');

select * from categoria_giocattoli

create table giocattoli (
id_giocattolo integer primary key auto_increment,
descizione_giocattolo varchar (100),
id_categoria_giocattolo integer,
prezzo decimal (10,2),
foreign key (id_categoria_giocattolo) references categoria_giocattoli(id_categoria_giocattolo));

insert into giocattoli (descizione_giocattolo, id_categoria_giocattolo, prezzo) values
('Aquilone',8,10.99),
('Auto Telecomandata',13,31.99),
('Bambole di Pezza',2,9.99),
('Casetta dei Giocattoli',5,41.99),
('Casetta delle Bambole',2,49.99),
('Cassetta degli Attrezzi',5,18.99),
('Cucina Giocattolo',5,39.99),
('Giochi di Scienza',5,20.99),
('Giostra a Cavallo',8,32.99),
('Giostra a Corrente',8,47.99),
('Giostra a Dondolo',8,38.99),
('Giostra a Molla',8,29.99),
('Giostra a Vento',8,36.99),
('Kit di Costruzione',3,15.99),
('Kit di Cucito',1,11.99),
('Kit di Esperimenti',5,26.99),
('Kit di Giochi Artistici',1,17.99),
('Kit di Giochi da Tavolo',9,27.99),
('Kit di Giochi di Logica',12,12.99),
('Kit di Giochi di Società',9,22.99),
('Kit di Magia',10,14.99),
('Kit di Modellismo',14,21.99),
('Kit di Modellismo Navale',14,19.99),
('Kit di Pittura',1,12.99),
('Macchinina RC',13,24.99),
('Modellino di Aereo',14,23.99),
('Pallone da Basket',8,16.99),
('Pallone da Calcio',8,17.99),
('Peluche Orso',15,14.99),
('Piscina Gonfiabile',8,54.99),
('Pista da Corsa',6,34.99),
('Playset Castello',11,28.99),
('Puzzle Disney',16,12.99),
('Robot Giocattolo',7,44.99),
('Set di Bowling',8,18.99),
('Set di Carte da Gioco',9,8.99),
('Set di Costruzioni',3,19.99),
('Set di Dinosauri',5,23.99),
('Set di Gessetti',1,7.99),
('Set di Giochi Magnetici',5,13.99),
('Set di Matite Colorate',1,6.99),
('Set di Mattoncini Lego',3,25.99),
('Set di Pennarelli',1,8.99),
('Set di Pennelli',1,9.99),
('Set di Robotica',7,39.99),
('Set di Strumenti Musicali',5,33.99),
('Set di Vernici',1,10.99),
('Tavolino da Disegno',5,25.99),
('Treno Giocattolo',6,28.99),
('Triciclo',4,49.99);

select * from giocattoli

drop table transazioni;

create table transazioni (
transazione_id integer primary key auto_increment,
id_paese integer,
id_giocattolo integer,
data_transazione date,
quantita integer,
foreign key (id_paese) references paesi(id_paese),
foreign key (id_giocattolo) references giocattoli(id_giocattolo));

insert into transazioni (id_paese, id_giocattolo, data_transazione, quantita) values
(23,33,'2022-1-1',2),
(16,25,'2022-1-15',1),
(11,3,'2022-1-29',3),
(14,37,'2022-2-12',2),
(17,29,'2022-2-26',1),
(33,12,'2022-3-12',4),
(36,24,'2022-3-26',2),
(40,7,'2022-4-9',1),
(18,28,'2022-4-23',3),
(35,22,'2022-5-7',2),
(23,33,'2022-5-21',1),
(16,25,'2022-6-4',2),
(11,3,'2022-6-18',3),
(14,37,'2022-7-2',1),
(17,29,'2022-7-16',4),
(33,12,'2022-7-30',2),
(36,24,'2022-8-13',3),
(40,7,'2022-8-27',1),
(18,28,'2022-9-10',2),
(35,22,'2022-9-24',3),
(23,33,'2022-10-8',1),
(16,25,'2022-10-22',4),
(11,3,'2022-11-5',2),
(14,37,'2022-11-19',1),
(17,29,'2022-12-3',3),
(33,12,'2022-12-17',2),
(36,24,'2022-12-31',1),
(40,7,'2023-1-14',4),
(18,28,'2023-1-28',2),
(35,22,'2023-2-11',3),
(23,33,'2023-2-25',1),
(16,25,'2023-3-11',2),
(11,3,'2023-3-25',3),
(14,37,'2023-4-8',2),
(17,29,'2023-4-22',1),
(33,12,'2023-5-6',4),
(36,24,'2023-5-20',2),
(40,7,'2023-6-3',1),
(18,28,'2023-6-17',3),
(35,22,'2023-7-1',2),
(23,33,'2023-7-15',1),
(16,25,'2023-7-29',4),
(11,3,'2023-8-12',2),
(14,37,'2023-8-26',3),
(17,29,'2023-9-9',1),
(33,12,'2023-9-23',2),
(36,24,'2023-10-7',3),
(40,7,'2023-10-21',1),
(18,28,'2023-11-4',4),
(35,22,'2023-11-18',2);

select * from transazioni;

-- 1. Verificare che i campi definiti come PK siano univoci -> tutte le chiavi pk sono auto_increment

-- 2. Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

select giocattoli.descizione_giocattolo as descrizione_giocattolo, year(transazioni.data_transazione) as anno, sum(transazioni.quantita * giocattoli.prezzo) as fatturato from
transazioni
join giocattoli on transazioni.id_giocattolo=giocattoli.id_giocattolo
group by giocattoli.descizione_giocattolo, year(data_transazione)
order by giocattoli.descizione_giocattolo, year(transazioni.data_transazione);

-- 3. Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente

select paesi.nome_paese as paese, year(transazioni.data_transazione) as anno, sum(transazioni.quantita * giocattoli.prezzo) as fatturato from
transazioni
join giocattoli on transazioni.id_giocattolo=giocattoli.id_giocattolo
join paesi on transazioni.id_paese=paesi.id_paese
group by paesi.nome_paese, year(transazioni.data_transazione)
order by anno, sum(transazioni.quantita * giocattoli.prezzo) desc;

-- 4. Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato? 

select categoria_giocattoli.descrizione_categoria_giocattolo as categoria_giocattoli, sum(transazioni.quantita) as pezzi_venduti from
transazioni
join giocattoli on transazioni.id_giocattolo=giocattoli.id_giocattolo
join categoria_giocattoli on giocattoli.id_categoria_giocattolo=categoria_giocattoli.id_categoria_giocattolo
group by categoria_giocattoli.descrizione_categoria_giocattolo
order by sum(transazioni.quantita) desc
limit 1;

-- 5 Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

select giocattoli.descizione_giocattolo as giocattolo from giocattoli 
left join transazioni on giocattoli.id_giocattolo=transazioni.id_giocattolo
group by giocattoli.descizione_giocattolo
having count(transazioni.quantita)=0

select giocattoli.descizione_giocattolo as giocattolo from giocattoli
where giocattoli.descizione_giocattolo <>all (
select giocattoli.descizione_giocattolo as giocattolo from giocattoli 
left join transazioni on giocattoli.id_giocattolo=transazioni.id_giocattolo
group by giocattoli.descizione_giocattolo
having count(transazioni.quantita)>0);

-- 6. Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select giocattoli.descizione_giocattolo as descrizione_giocattolo, transazioni.data_transazione as data_transazione from
transazioni
join giocattoli on transazioni.id_giocattolo=giocattoli.id_giocattolo
order by transazioni.data_transazione desc;

/* BONUS: Esporre l’elenco delle transazioni indicando nel result set 
il codice documento, la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita
 e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)
 */


select transazioni.transazione_id as codice_documento, transazioni.data_transazione as data_transazione, giocattoli.descizione_giocattolo as giocattolo,
categoria_giocattoli.descrizione_categoria_giocattolo as categoria_giocattoli, regioni.nome_regione as regione,
case
when datediff('2023-12-31',transazioni.data_transazione)<=180 then "Ordine Recente"
else 'Non recente'
end as Commento
from transazioni
join giocattoli on transazioni.id_giocattolo=giocattoli.id_giocattolo
join paesi on transazioni.id_paese=paesi.id_paese
join categoria_giocattoli on giocattoli.id_categoria_giocattolo=categoria_giocattoli.id_categoria_giocattolo
join regioni on paesi.id_regione=regioni.id_regione

